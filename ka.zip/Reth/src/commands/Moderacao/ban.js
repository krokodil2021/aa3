module.exports = (client, message, args) => {
    // Funcionamento igual ao vaza, então é melhor redirecionar de uma vez
    client.commands.vaza(client, message, args);
};