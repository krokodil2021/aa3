module.exports = (client, message, args) => {
    client.commands.registrar(client, message, args);
};