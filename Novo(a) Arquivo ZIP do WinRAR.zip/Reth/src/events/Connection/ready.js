module.exports = client => {
    console.log(`Logado como ${client.user.tag}`);
};
