module.exports = message => {
    message.reply("Você digitou alguma coisa errada!");
};