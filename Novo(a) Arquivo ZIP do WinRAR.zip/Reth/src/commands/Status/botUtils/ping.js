module.exports = (client, message) => {
    client.commands.ping(client, message);
};