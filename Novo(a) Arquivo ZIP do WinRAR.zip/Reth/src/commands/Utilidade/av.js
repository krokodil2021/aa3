module.exports = (client, message) => {
    client.commands.avatar(client, message);
};